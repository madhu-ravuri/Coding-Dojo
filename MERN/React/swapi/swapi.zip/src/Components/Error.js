import React from 'react';

const Error = (props) => {
    return(
        <div>
            <p>These aren't the droids you're looking for!</p>
            <img src="https://cdn.vox-cdn.com/thumbor/ICjwWQhDmr48CIKabxxQilwTVfg=/0x0:786x393/920x613/filters:focal(331x135:455x259):format(webp)/cdn.vox-cdn.com/uploads/chorus_image/image/65101167/obi-wan.0.0.jpg" alt="obi-wan" />
        </div>
    );
}

export default Error