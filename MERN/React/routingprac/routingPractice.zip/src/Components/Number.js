import React from 'react';

const Number = (props) => {

    return(
        <h1>The number is: {props.id}</h1>
    )
}

export default Number;