import React from 'react';

const WordOnly = (props) => {

    return(
        <h1>The word is: {props.word}</h1>
    )
}

export default WordOnly;