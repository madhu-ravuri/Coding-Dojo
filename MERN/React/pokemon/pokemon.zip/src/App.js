import React from 'react';
import './App.css';

import Pokemon from './Components/Pokemon';

function App() {
  return (
    <div className="App">
      <Pokemon />
    </div>
  );
}

export default App;
