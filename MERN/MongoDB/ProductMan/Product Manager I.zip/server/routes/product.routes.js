const ProductController = require('../controllers/Product.controller');

module.exports = function(app){
    app.post('/api/product', ProductController.createProduct);
}