import React, { useEffect, useState } from 'react'
import ProductForm from '../components/ProductForm';

export default () => {
    return (
        <div>
            <ProductForm />
        </div>
    )
}
