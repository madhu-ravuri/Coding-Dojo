import React from 'react';
import { Link } from '@reach/router';

export default props => {
    const { products, setProducts } = props;

    return (
        <div>
            {products.map((product, i)=> {
                return(
                    <div key={i}>
                    <Link to={`/products/${product._id}`}>{product.title}</Link>
                </div>
                )
            })}

        </div>
    )
}
