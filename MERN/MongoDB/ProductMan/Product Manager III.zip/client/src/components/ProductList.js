import React from 'react';
import { Link } from '@reach/router';
import axios from 'axios';

export default props => {
    const { products, setProducts } = props;

    const removeFromDom = productId => {
        setProducts(products.filter(product => product._id != productId));
    }
    
    // const { removeFromDom } = props;
    const deleteProduct = (productId) => {
        axios.delete('http://localhost:8000/api/products/' + productId)
            .then(res => {
                removeFromDom(productId)
            })
    }

    return (
        <div>
            {products.map((product, i)=> {
                return(
                    <div key={i}>
                    <Link to={`/products/${product._id}`}>{product.title}</Link>
                    |
                    <button onClick={(e)=>{deleteProduct(product._id)}}>
                        Delete
                    </button>
                </div>
                )
            })}

        </div>
    )
}
