$(document).ready(function () {

   $("img").click(function () {
       $(this).fadeOut(400);
   });

   $("button").click(function () {
       $(".icons").fadeIn(400);
   });

});